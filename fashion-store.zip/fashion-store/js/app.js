/**
 * Main Application Module
 * Global functionality, cart management, WhatsApp integration
 */

// ===========================
// CART MANAGEMENT
// ===========================

class Cart {
  constructor() {
    this.items = this.loadCart();
  }

  loadCart() {
    const stored = localStorage.getItem('fashionCart');
    return stored ? JSON.parse(stored) : [];
  }

  saveCart() {
    localStorage.setItem('fashionCart', JSON.stringify(this.items));
  }

  addItem(product, size, color, quantity) {
    const existingItem = this.items.find(
      item => item.id === product.id && item.size === size && item.color === color
    );

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      this.items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        size,
        color,
        quantity,
      });
    }

    this.saveCart();
    this.showCartNotification();
  }

  removeItem(id, size, color) {
    this.items = this.items.filter(
      item => !(item.id === id && item.size === size && item.color === color)
    );
    this.saveCart();
  }

  updateQuantity(id, size, color, quantity) {
    const item = this.items.find(
      item => item.id === id && item.size === size && item.color === color
    );
    if (item) {
      item.quantity = Math.max(0, quantity);
      if (item.quantity === 0) {
        this.removeItem(id, size, color);
      }
      this.saveCart();
    }
  }

  getTotal() {
    return this.items.reduce((total, item) => total + item.price * item.quantity, 0);
  }

  getItemCount() {
    return this.items.reduce((count, item) => count + item.quantity, 0);
  }

  clear() {
    this.items = [];
    this.saveCart();
  }

  showCartNotification() {
    const count = this.getItemCount();
    const cartBadge = document.getElementById('cartBadge');
    if (cartBadge) {
      cartBadge.textContent = count;
      cartBadge.style.display = count > 0 ? 'flex' : 'none';
    }
  }
}

// Initialize cart
const cart = new Cart();

// ===========================
// WHATSAPP INTEGRATION
// ===========================

function generateWhatsAppMessage(product, size, color, quantity) {
  const discount = calculateDiscount(product.mrp, product.price);
  const message = `Hello 👋, I want to order this product.\n\n*${product.name}*\n\nProduct ID: ${product.id}\nCategory: ${product.category}\nPrice: ${formatPrice(product.price)}\nMRP: ${formatPrice(product.mrp)}\nYou Save: ${formatPrice(product.mrp - product.price)} (${discount}% off)\n\nSize: ${size}\n${color ? `Color: ${color}` : ''}Quantity: ${quantity}\n\nPlease confirm availability and delivery charges.`;

  return encodeURIComponent(message);
}

function openWhatsApp(product, size, color = '', quantity = 1) {
  // Validate inputs
  if (!size || checkStock(product.id, size) === 0) {
    showNotification('Please select an available size', 'error');
    return;
  }

  const message = generateWhatsAppMessage(product, size, color, quantity);
  const whatsappUrl = `https://wa.me/${STORE_CONFIG.STORE_WHATSAPP}?text=${message}`;
  window.open(whatsappUrl, '_blank');
}

// ===========================
// NOTIFICATIONS
// ===========================

function showNotification(message, type = 'success', duration = 3000) {
  const notification = document.createElement('div');
  notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white z-50 animate-fade-in ${
    type === 'success' ? 'bg-green-600' : type === 'error' ? 'bg-red-600' : 'bg-blue-600'
  }`;
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.animation = 'fadeOut 0.3s ease-out';
    setTimeout(() => notification.remove(), 300);
  }, duration);
}

// ===========================
// MOBILE MENU
// ===========================

function setupMobileMenu() {
  const menuToggle = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const menuClose = document.getElementById('menuClose');

  if (!menuToggle) return;

  menuToggle.addEventListener('click', () => {
    mobileMenu.classList.remove('translate-x-full');
  });

  menuClose.addEventListener('click', () => {
    mobileMenu.classList.add('translate-x-full');
  });

  // Close menu when a link is clicked
  document.querySelectorAll('#mobileMenu a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.add('translate-x-full');
    });
  });

  // Close menu on ESC key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      mobileMenu.classList.add('translate-x-full');
    }
  });
}

// ===========================
// SEARCH FUNCTIONALITY
// ===========================

function setupSearch() {
  const searchInput = document.getElementById('searchInput');
  if (!searchInput) return;

  searchInput.addEventListener('input', e => {
    const query = e.target.value;
    if (query.length < 2) {
      document.getElementById('searchResults').innerHTML = '';
      return;
    }

    const results = searchProducts(query);
    displaySearchResults(results, query);
  });
}

function displaySearchResults(results, query) {
  const resultsContainer = document.getElementById('searchResults');
  if (!resultsContainer) return;

  if (results.length === 0) {
    resultsContainer.innerHTML = `
      <div class="p-4 text-center text-gray-400">
        No products found for "${query}"
      </div>
    `;
    return;
  }

  resultsContainer.innerHTML = results
    .map(
      product => `
    <a href="product.html?id=${product.id}" class="block p-3 hover:bg-opacity-80 border-b border-gray-700 transition">
      <div class="flex gap-3">
        <img src="${product.image}" alt="${product.name}" class="w-12 h-12 object-cover rounded">
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium text-white truncate">${product.name}</p>
          <p class="text-xs text-gray-400">${product.category}</p>
          <p class="text-sm text-yellow-600 font-semibold">${formatPrice(product.price)}</p>
        </div>
      </div>
    </a>
  `
    )
    .join('');
}

// ===========================
// SHARE PRODUCT
// ===========================

function setupShareProduct() {
  const shareButtons = document.querySelectorAll('.share-product');
  shareButtons.forEach(btn => {
    btn.addEventListener('click', async e => {
      e.preventDefault();
      const productId = btn.dataset.productId;
      const product = getProductById(productId);

      if (!product) return;

      const shareData = {
        title: product.name,
        text: `Check out ${product.name} - ${formatPrice(product.price)}`,
        url: `${window.location.origin}/product.html?id=${productId}`,
      };

      if (navigator.share) {
        try {
          await navigator.share(shareData);
        } catch (err) {
          if (err.name !== 'AbortError') {
            console.error('Share failed:', err);
          }
        }
      } else {
        // Fallback: Copy to clipboard
        const text = `${shareData.text}\n${shareData.url}`;
        navigator.clipboard.writeText(text).then(() => {
          showNotification('Link copied to clipboard!', 'success');
        });
      }
    });
  });
}

// ===========================
// LAZY LOADING IMAGES
// ===========================

function setupLazyLoading() {
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.remove('blur-sm');
          observer.unobserve(img);
        }
      });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }
}

// ===========================
// SMOOTH SCROLL
// ===========================

document.addEventListener('DOMContentLoaded', () => {
  // Enable smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href !== '#') {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });
});

// ===========================
// PAGE INITIALIZATION
// ===========================

document.addEventListener('DOMContentLoaded', () => {
  setupMobileMenu();
  setupSearch();
  setupLazyLoading();
  setupShareProduct();
  cart.showCartNotification();
});

// Update cart badge when page is shown (after returning from another tab)
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    cart.showCartNotification();
  }
});
