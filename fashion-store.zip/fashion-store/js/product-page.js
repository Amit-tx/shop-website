/**
 * Product Detail Page Module
 * Product display, size selection, quantity, ordering
 */

class ProductPageManager {
  constructor() {
    this.product = null;
    this.selectedSize = null;
    this.selectedColor = null;
    this.quantity = 1;
    this.loadProduct();
  }

  loadProduct() {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');

    if (!productId) {
      this.showError('Product not found');
      return;
    }

    this.product = getProductById(productId);

    if (!this.product) {
      this.showError('Product not found');
      return;
    }

    this.render();
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Size selection
    document.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        const size = e.target.dataset.size;
        const stock = checkStock(this.product.id, size);

        if (stock === 0) {
          showNotification('This size is out of stock', 'error');
          return;
        }

        document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.selectedSize = size;
      });
    });

    // Color selection
    document.querySelectorAll('.color-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.selectedColor = e.target.dataset.color;
      });
    });

    // Quantity
    const qtyInput = document.getElementById('quantityInput');
    if (qtyInput) {
      qtyInput.addEventListener('change', e => {
        this.quantity = Math.max(1, parseInt(e.target.value) || 1);
        qtyInput.value = this.quantity;
      });
    }

    document.getElementById('decreaseQty')?.addEventListener('click', () => {
      this.quantity = Math.max(1, this.quantity - 1);
      document.getElementById('quantityInput').value = this.quantity;
    });

    document.getElementById('increaseQty')?.addEventListener('click', () => {
      this.quantity += 1;
      document.getElementById('quantityInput').value = this.quantity;
    });

    // WhatsApp order
    document.getElementById('orderWhatsApp')?.addEventListener('click', () => {
      if (!this.selectedSize) {
        showNotification('Please select a size', 'error');
        return;
      }

      openWhatsApp(this.product, this.selectedSize, this.selectedColor, this.quantity);
    });

    // Add to cart
    document.getElementById('addToCart')?.addEventListener('click', () => {
      if (!this.selectedSize) {
        showNotification('Please select a size', 'error');
        return;
      }

      cart.addItem(this.product, this.selectedSize, this.selectedColor, this.quantity);
      showNotification('Added to cart!', 'success');
    });

    // Gallery
    this.setupGallery();
  }

  setupGallery() {
    if (!this.product.gallery || this.product.gallery.length <= 1) return;

    const mainImage = document.getElementById('mainImage');
    const thumbnails = document.querySelectorAll('.gallery-thumbnail');

    thumbnails.forEach((thumb, index) => {
      thumb.addEventListener('click', () => {
        mainImage.src = this.product.gallery[index];
        thumbnails.forEach(t => t.classList.remove('ring-2'));
        thumb.classList.add('ring-2');
      });
    });
  }

  showError(message) {
    const container = document.getElementById('productContainer');
    if (container) {
      container.innerHTML = `
        <div class="text-center py-12">
          <p class="text-red-500 text-lg mb-4">${message}</p>
          <a href="shop.html" class="text-yellow-600 hover:text-yellow-700 font-semibold">
            ← Back to Shop
          </a>
        </div>
      `;
    }
  }

  render() {
    const discount = calculateDiscount(this.product.mrp, this.product.price);
    const savings = this.product.mrp - this.product.price;

    const container = document.getElementById('productContainer');
    if (!container) return;

    container.innerHTML = `
      <!-- Desktop Layout -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <!-- Gallery -->
        <div class="space-y-4">
          <div class="bg-gray-800 rounded-lg overflow-hidden">
            <img id="mainImage" src="${this.product.image}" alt="${this.product.name}" class="w-full h-96 object-cover">
          </div>
          
          ${
            this.product.gallery && this.product.gallery.length > 1
              ? `
            <div class="flex gap-2 overflow-x-auto pb-2">
              ${this.product.gallery
                .map(
                  (img, idx) => `
                <img 
                  src="${img}" 
                  alt="Gallery ${idx + 1}"
                  class="gallery-thumbnail w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80 transition ${idx === 0 ? 'ring-2 ring-yellow-600' : ''}"
                >
              `
                )
                .join('')}
            </div>
          `
              : ''
          }
        </div>

        <!-- Product Info -->
        <div class="space-y-6">
          <div>
            <p class="text-xs text-gray-400 uppercase tracking-wider">${this.product.category}</p>
            <h1 class="text-3xl md:text-4xl font-bold text-white mt-2">${this.product.name}</h1>
          </div>

          <!-- Pricing -->
          <div class="space-y-2 border-b border-gray-700 pb-6">
            <div class="flex items-baseline gap-3">
              <span class="text-3xl font-bold text-yellow-500">${formatPrice(this.product.price)}</span>
              ${this.product.mrp ? `<span class="text-lg text-gray-400 line-through">${formatPrice(this.product.mrp)}</span>` : ''}
              ${discount > 0 ? `<span class="text-sm bg-red-600 text-white px-2 py-1 rounded font-semibold">${discount}% OFF</span>` : ''}
            </div>
            ${
              savings > 0
                ? `<p class="text-green-500 font-semibold">Save ${formatPrice(savings)}</p>`
                : ''
            }
          </div>

          <!-- Stock Status -->
          <div>
            <p class="text-sm text-gray-400">
              <span class="text-green-500 font-semibold">✓ In Stock</span> - ${
                Object.values(this.product.stock).reduce((a, b) => a + b, 0)
              } items available
            </p>
          </div>

          <!-- Size Selection -->
          <div>
            <label class="block text-sm font-semibold text-white mb-3">Select Size</label>
            <div class="flex gap-2 flex-wrap">
              ${this.product.sizes
                .map(size => {
                  const stock = checkStock(this.product.id, size);
                  return `
                <button
                  class="size-btn px-4 py-2 rounded border border-gray-700 hover:border-yellow-600 transition ${stock === 0 ? 'opacity-50 cursor-not-allowed text-gray-500' : 'text-white hover:text-yellow-600'}"
                  data-size="${size}"
                  ${stock === 0 ? 'disabled' : ''}
                >
                  ${size}
                  ${stock === 0 ? '<br><span class="text-xs">(Out of Stock)</span>' : ''}
                </button>
              `;
                })
                .join('')}
            </div>
          </div>

          <!-- Color Selection -->
          ${
            this.product.colors && this.product.colors.length > 0
              ? `
            <div>
              <label class="block text-sm font-semibold text-white mb-3">Select Color</label>
              <div class="flex gap-2 flex-wrap">
                ${this.product.colors
                  .map(
                    (color, idx) => `
                  <button
                    class="color-btn px-4 py-2 rounded border border-gray-700 hover:border-yellow-600 transition text-white hover:text-yellow-600 ${idx === 0 ? 'active border-yellow-600 text-yellow-600' : ''}"
                    data-color="${color}"
                  >
                    ${color}
                  </button>
                `
                  )
                  .join('')}
              </div>
            </div>
          `
              : ''
          }

          <!-- Quantity -->
          <div>
            <label class="block text-sm font-semibold text-white mb-3">Quantity</label>
            <div class="flex items-center gap-2 w-fit">
              <button id="decreaseQty" class="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded transition">−</button>
              <input id="quantityInput" type="number" value="1" min="1" max="10" class="w-12 text-center bg-gray-800 text-white border border-gray-700 rounded py-2">
              <button id="increaseQty" class="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded transition">+</button>
            </div>
          </div>

          <!-- CTA Buttons -->
          <div class="space-y-3 pt-4">
            <button id="orderWhatsApp" class="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg transition flex items-center justify-center gap-2">
              <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371 0-.57 0-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-9.746 9.798c0 2.7.734 5.31 2.126 7.565l-2.258 8.242a.75.75 0 00.95.95l8.24-2.258c2.254 1.39 4.865 2.125 7.565 2.125 5.39 0 9.797-4.406 9.797-9.796 0-2.593-.994-5.032-2.801-6.84-1.81-1.809-4.248-2.803-6.84-2.803z"/></svg>
              ORDER ON WHATSAPP
            </button>
            <button id="addToCart" class="w-full py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold rounded-lg transition border border-gray-700">
              ADD TO CART
            </button>
            <button class="share-product w-full py-2 text-gray-300 hover:text-yellow-600 font-semibold rounded transition" data-product-id="${this.product.id}">
              SHARE PRODUCT
            </button>
          </div>
        </div>
      </div>

      <!-- Product Details -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 py-8 border-t border-gray-700">
        <div class="space-y-4">
          <h2 class="text-xl font-bold text-white">Product Details</h2>
          <div class="space-y-3 text-sm">
            ${this.product.fabric ? `<div><span class="text-gray-400">Fabric:</span> <span class="text-white">${this.product.fabric}</span></div>` : ''}
            ${this.product.fit ? `<div><span class="text-gray-400">Fit:</span> <span class="text-white">${this.product.fit}</span></div>` : ''}
            ${this.product.colors ? `<div><span class="text-gray-400">Colors:</span> <span class="text-white">${this.product.colors.join(', ')}</span></div>` : ''}
            <div><span class="text-gray-400">Available Sizes:</span> <span class="text-white">${this.product.sizes.join(', ')}</span></div>
          </div>
        </div>

        <div class="space-y-4">
          <h2 class="text-xl font-bold text-white">Care Instructions</h2>
          <p class="text-sm text-gray-300">${this.product.careInstructions || 'Please refer to the care label on the product.'}</p>
        </div>
      </div>

      <!-- Delivery & Exchange Info -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 py-8 border-t border-gray-700">
        <div class="space-y-3">
          <h3 class="text-lg font-bold text-white flex items-center gap-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8"/></svg>
            Delivery
          </h3>
          <p class="text-sm text-gray-300">Delivery charges depend on your location (₹49-99).</p>
          <p class="text-sm text-gray-400">Estimated delivery: 2-3 business days</p>
          <a href="delivery.html" class="text-yellow-600 hover:text-yellow-700 text-sm font-semibold">Learn more →</a>
        </div>

        <div class="space-y-3">
          <h3 class="text-lg font-bold text-white flex items-center gap-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            Exchange
          </h3>
          <p class="text-sm text-gray-300">Exchange available within 7 days of purchase.</p>
          <p class="text-sm text-gray-400">Product must be unused with original tags attached.</p>
          <a href="exchange.html" class="text-yellow-600 hover:text-yellow-700 text-sm font-semibold">Learn more →</a>
        </div>
      </div>
    `;

    // Update color selection default
    if (this.product.colors && this.product.colors.length > 0) {
      this.selectedColor = this.product.colors[0];
    }

    // Setup event listeners after render
    this.setupEventListeners();
  }
}

// Initialize product page when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new ProductPageManager();
});
