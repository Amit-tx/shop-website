/**
 * Product Database
 * All products stored in a structured format
 */

const PRODUCTS = [
  // Men's T-Shirts
  {
    id: 'tshirt-001',
    name: "Classic Crew Neck T-Shirt",
    category: 'Men',
    subcategory: 'T-Shirts',
    price: 399,
    mrp: 799,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1608231387042-ec70ee9d6a39?w=500&h=500&fit=crop',
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    stock: { S: 5, M: 8, L: 6, XL: 3, XXL: 2 },
    colors: ['Black', 'White', 'Navy'],
    description: 'Premium cotton t-shirt perfect for everyday wear.',
    featured: true,
    newArrival: true,
    sale: true,
    fabric: '100% Cotton',
    fit: 'Regular',
    careInstructions: 'Machine wash warm. Do not bleach. Tumble dry low.',
  },
  {
    id: 'tshirt-002',
    name: "Striped Summer Tee",
    category: 'Men',
    subcategory: 'T-Shirts',
    price: 349,
    mrp: 699,
    image: 'https://images.unsplash.com/photo-1608231387042-ec70ee9d6a39?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1608231387042-ec70ee9d6a39?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    ],
    sizes: ['M', 'L', 'XL', 'XXL'],
    stock: { M: 4, L: 7, XL: 5, XXL: 0 },
    colors: ['Navy-White', 'Black-White'],
    description: 'Comfortable striped tee ideal for summer outings.',
    featured: false,
    newArrival: true,
    sale: false,
    fabric: '95% Cotton, 5% Elastane',
    fit: 'Slim',
    careInstructions: 'Machine wash cold. Do not bleach. Hang dry.',
  },
  // Men's Shirts
  {
    id: 'shirt-001',
    name: "Casual Linen Shirt",
    category: 'Men',
    subcategory: 'Shirts',
    price: 599,
    mrp: 1199,
    image: 'https://images.unsplash.com/photo-1596215514033-d6f0b5f55742?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1596215514033-d6f0b5f55742?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1540754747409-e6f99042daec?w=500&h=500&fit=crop',
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    stock: { S: 2, M: 6, L: 4, XL: 3 },
    colors: ['Beige', 'Khaki', 'White'],
    description: 'Lightweight linen shirt perfect for casual summer looks.',
    featured: true,
    newArrival: false,
    sale: true,
    fabric: '100% Linen',
    fit: 'Relaxed',
    careInstructions: 'Machine wash warm. Iron while damp.',
  },
  {
    id: 'shirt-002',
    name: "Oxford Striped Shirt",
    category: 'Men',
    subcategory: 'Shirts',
    price: 699,
    mrp: 1499,
    image: 'https://images.unsplash.com/photo-1540754747409-e6f99042daec?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1540754747409-e6f99042daec?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1596215514033-d6f0b5f55742?w=500&h=500&fit=crop',
    ],
    sizes: ['M', 'L', 'XL', 'XXL'],
    stock: { M: 3, L: 5, XL: 4, XXL: 2 },
    colors: ['Blue', 'White', 'Burgundy'],
    description: 'Classic oxford fabric shirt with timeless appeal.',
    featured: false,
    newArrival: false,
    sale: false,
    fabric: '100% Cotton Oxford',
    fit: 'Regular',
    careInstructions: 'Machine wash cold. Iron when slightly damp.',
  },
  // Men's Jeans
  {
    id: 'jeans-001',
    name: "Dark Denim Slim Fit",
    category: 'Men',
    subcategory: 'Jeans',
    price: 799,
    mrp: 1599,
    image: 'https://images.unsplash.com/photo-1542272604-787c62d465d1?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1542272604-787c62d465d1?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1474886872297-aab3b63e0c0f?w=500&h=500&fit=crop',
    ],
    sizes: ['28', '30', '32', '34', '36'],
    stock: { '28': 2, '30': 5, '32': 6, '34': 4, '36': 1 },
    colors: ['Dark Indigo'],
    description: 'Premium dark denim jeans with excellent stretch.',
    featured: true,
    newArrival: false,
    sale: true,
    fabric: '98% Cotton, 2% Elastane',
    fit: 'Slim',
    careInstructions: 'Machine wash cold. Turn inside out. Do not bleach.',
  },
  {
    id: 'jeans-002',
    name: "Light Wash Relaxed Jeans",
    category: 'Men',
    subcategory: 'Jeans',
    price: 649,
    mrp: 1299,
    image: 'https://images.unsplash.com/photo-1474886872297-aab3b63e0c0f?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1474886872297-aab3b63e0c0f?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1542272604-787c62d465d1?w=500&h=500&fit=crop',
    ],
    sizes: ['28', '30', '32', '34', '36', '38'],
    stock: { '28': 3, '30': 4, '32': 5, '34': 6, '36': 3, '38': 1 },
    colors: ['Light Blue'],
    description: 'Comfortable relaxed fit jeans in light wash.',
    featured: false,
    newArrival: true,
    sale: false,
    fabric: '100% Cotton',
    fit: 'Relaxed',
    careInstructions: 'Machine wash cold. Turn inside out. Hang dry.',
  },
  // Women's Kurtis
  {
    id: 'kurti-001',
    name: "Embroidered Cotton Kurti",
    category: 'Women',
    subcategory: 'Kurtis',
    price: 549,
    mrp: 1099,
    image: 'https://images.unsplash.com/photo-1565886557129-d3f456d0f76b?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1565886557129-d3f456d0f76b?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1609529859471-40231a96cf6e?w=500&h=500&fit=crop',
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    stock: { XS: 2, S: 4, M: 6, L: 5, XL: 3, XXL: 2 },
    colors: ['Navy', 'Cream', 'Rust'],
    description: 'Traditional embroidered kurti with modern silhouette.',
    featured: true,
    newArrival: true,
    sale: true,
    fabric: '100% Cotton',
    fit: 'Regular',
    careInstructions: 'Hand wash or machine wash gentle. Air dry.',
  },
  {
    id: 'kurti-002',
    name: "Printed Rayon Kurti",
    category: 'Women',
    subcategory: 'Kurtis',
    price: 449,
    mrp: 899,
    image: 'https://images.unsplash.com/photo-1609529859471-40231a96cf6e?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1609529859471-40231a96cf6e?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1565886557129-d3f456d0f76b?w=500&h=500&fit=crop',
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    stock: { XS: 1, S: 3, M: 5, L: 4, XL: 2 },
    colors: ['Maroon', 'Purple', 'Green'],
    description: 'Flowing rayon kurti with beautiful floral prints.',
    featured: false,
    newArrival: false,
    sale: false,
    fabric: '100% Rayon',
    fit: 'A-Line',
    careInstructions: 'Hand wash. Do not wring. Dry in shade.',
  },
  // Women's Dresses
  {
    id: 'dress-001',
    name: "Summer Sundress",
    category: 'Women',
    subcategory: 'Dresses',
    price: 699,
    mrp: 1399,
    image: 'https://images.unsplash.com/photo-1515762136207-29891840faee?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1515762136207-29891840faee?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    stock: { XS: 2, S: 5, M: 4, L: 3, XL: 1 },
    colors: ['Floral', 'Solid Blue'],
    description: 'Lightweight sundress perfect for warm weather.',
    featured: true,
    newArrival: true,
    sale: true,
    fabric: '100% Cotton',
    fit: 'Loose',
    careInstructions: 'Machine wash cool. Tumble dry low.',
  },
  {
    id: 'dress-002',
    name: "Casual A-Line Dress",
    category: 'Women',
    subcategory: 'Dresses',
    price: 799,
    mrp: 1599,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1515762136207-29891840faee?w=500&h=500&fit=crop',
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    stock: { XS: 1, S: 3, M: 4, L: 5, XL: 2, XXL: 1 },
    colors: ['Black', 'Burgundy', 'Teal'],
    description: 'Elegant A-line dress for casual or semi-formal occasions.',
    featured: false,
    newArrival: false,
    sale: false,
    fabric: '95% Cotton, 5% Elastane',
    fit: 'A-Line',
    careInstructions: 'Machine wash cold. Iron on medium heat.',
  },
  // Kids
  {
    id: 'kids-001',
    name: "Kids Graphic T-Shirt",
    category: 'Kids',
    subcategory: 'T-Shirts',
    price: 249,
    mrp: 499,
    image: 'https://images.unsplash.com/photo-1503919545889-e140bc05e5b4?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1503919545889-e140bc05e5b4?w=500&h=500&fit=crop',
    ],
    sizes: ['4Y', '6Y', '8Y', '10Y', '12Y'],
    stock: { '4Y': 3, '6Y': 5, '8Y': 6, '10Y': 4, '12Y': 2 },
    colors: ['Blue', 'Red', 'Green'],
    description: 'Fun and colorful graphic tee for kids.',
    featured: false,
    newArrival: true,
    sale: true,
    fabric: '100% Cotton',
    fit: 'Regular',
    careInstructions: 'Machine wash warm. Tumble dry.',
  },
  {
    id: 'kids-002',
    name: "Kids Casual Shorts",
    category: 'Kids',
    subcategory: 'Other',
    price: 299,
    mrp: 599,
    image: 'https://images.unsplash.com/photo-1575428774223-a3a147dc6ceb?w=500&h=500&fit=crop',
    gallery: [
      'https://images.unsplash.com/photo-1575428774223-a3a147dc6ceb?w=500&h=500&fit=crop',
    ],
    sizes: ['4Y', '6Y', '8Y', '10Y', '12Y'],
    stock: { '4Y': 2, '6Y': 4, '8Y': 5, '10Y': 3, '12Y': 2 },
    colors: ['Navy', 'Khaki'],
    description: 'Comfortable shorts perfect for active kids.',
    featured: false,
    newArrival: false,
    sale: false,
    fabric: '100% Cotton',
    fit: 'Regular',
    careInstructions: 'Machine wash warm. Tumble dry.',
  },
];

/**
 * Utility function to get a product by ID
 */
function getProductById(id) {
  return PRODUCTS.find(p => p.id === id);
}

/**
 * Utility function to get products by category
 */
function getProductsByCategory(category) {
  if (category === 'All') return PRODUCTS;
  return PRODUCTS.filter(p => p.category === category);
}

/**
 * Utility function to get products by subcategory
 */
function getProductsBySubcategory(subcategory) {
  return PRODUCTS.filter(p => p.subcategory === subcategory);
}

/**
 * Utility function to search products
 */
function searchProducts(query) {
  const q = query.toLowerCase();
  return PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.category.toLowerCase().includes(q) ||
    p.subcategory.toLowerCase().includes(q)
  );
}

/**
 * Utility function to get featured products
 */
function getFeaturedProducts() {
  return PRODUCTS.filter(p => p.featured);
}

/**
 * Utility function to get new arrivals
 */
function getNewArrivals() {
  return PRODUCTS.filter(p => p.newArrival);
}

/**
 * Utility function to get sale products
 */
function getSaleProducts() {
  return PRODUCTS.filter(p => p.sale);
}

/**
 * Utility function to check stock for a size
 */
function checkStock(productId, size) {
  const product = getProductById(productId);
  if (!product) return 0;
  return product.stock[size] || 0;
}

/**
 * Utility function to calculate discount
 */
function calculateDiscount(mrp, price) {
  if (!mrp || !price) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}

/**
 * Utility function to format price
 */
function formatPrice(price) {
  return `₹${price.toLocaleString('en-IN')}`;
}
