/**
 * Shop Page Module
 * Filtering, sorting, and product display
 */

class ShopManager {
  constructor() {
    this.allProducts = [...PRODUCTS];
    this.filteredProducts = [...PRODUCTS];
    this.filters = {
      category: 'All',
      subcategory: 'All',
      priceRange: 'All',
    };
    this.sortBy = 'newest';
    this.setupEventListeners();
    this.render();
  }

  setupEventListeners() {
    // Category filters
    document.querySelectorAll('.category-filter').forEach(btn => {
      btn.addEventListener('click', e => {
        document.querySelectorAll('.category-filter').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.filters.category = e.target.dataset.category;
        this.filters.subcategory = 'All';
        this.applyFilters();
      });
    });

    // Subcategory filters
    document.querySelectorAll('.subcategory-filter').forEach(btn => {
      btn.addEventListener('click', e => {
        document.querySelectorAll('.subcategory-filter').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.filters.subcategory = e.target.dataset.subcategory;
        this.applyFilters();
      });
    });

    // Price filters
    document.querySelectorAll('.price-filter').forEach(btn => {
      btn.addEventListener('click', e => {
        document.querySelectorAll('.price-filter').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.filters.priceRange = e.target.dataset.range;
        this.applyFilters();
      });
    });

    // Sort
    document.getElementById('sortSelect').addEventListener('change', e => {
      this.sortBy = e.target.value;
      this.applySorting();
      this.render();
    });

    // Reset filters
    document.getElementById('resetFilters').addEventListener('click', () => {
      this.resetFilters();
    });
  }

  applyFilters() {
    this.filteredProducts = [...this.allProducts];

    // Category filter
    if (this.filters.category !== 'All') {
      this.filteredProducts = this.filteredProducts.filter(
        p => p.category === this.filters.category
      );
    }

    // Subcategory filter
    if (this.filters.subcategory !== 'All') {
      this.filteredProducts = this.filteredProducts.filter(
        p => p.subcategory === this.filters.subcategory
      );
    }

    // Price filter
    if (this.filters.priceRange !== 'All') {
      this.filteredProducts = this.filteredProducts.filter(p => {
        const price = p.price;
        switch (this.filters.priceRange) {
          case '0-399':
            return price < 400;
          case '400-599':
            return price >= 400 && price < 600;
          case '600-999':
            return price >= 600 && price < 1000;
          case '1000+':
            return price >= 1000;
          default:
            return true;
        }
      });
    }

    this.applySorting();
    this.render();
  }

  applySorting() {
    switch (this.sortBy) {
      case 'price-low':
        this.filteredProducts.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        this.filteredProducts.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
      default:
        this.filteredProducts.sort((a, b) => {
          if (a.newArrival && !b.newArrival) return -1;
          if (!a.newArrival && b.newArrival) return 1;
          return 0;
        });
        break;
    }
  }

  resetFilters() {
    this.filters = { category: 'All', subcategory: 'All', priceRange: 'All' };
    this.sortBy = 'newest';

    document.querySelectorAll('.category-filter, .subcategory-filter, .price-filter').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector('.category-filter[data-category="All"]').classList.add('active');

    document.getElementById('sortSelect').value = 'newest';

    this.applyFilters();
  }

  render() {
    const container = document.getElementById('productsGrid');
    if (!container) return;

    if (this.filteredProducts.length === 0) {
      container.innerHTML = `
        <div class="col-span-full text-center py-12">
          <p class="text-gray-400 text-lg">No products found</p>
          <button onclick="shop.resetFilters()" class="mt-4 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded transition">
            Reset Filters
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = this.filteredProducts.map(product => this.createProductCard(product)).join('');

    // Re-setup product card listeners
    this.setupProductCardListeners();
  }

  createProductCard(product) {
    const discount = calculateDiscount(product.mrp, product.price);
    const inStock = Object.values(product.stock).some(qty => qty > 0);

    return `
      <div class="bg-gray-800 rounded-lg overflow-hidden hover:shadow-lg transition transform hover:scale-105 duration-300">
        <div class="relative overflow-hidden h-64 bg-gray-900">
          <img 
            src="${product.image}" 
            alt="${product.name}"
            class="w-full h-full object-cover hover:scale-110 transition duration-300"
          >
          ${product.sale ? '<span class="absolute top-3 right-3 bg-red-600 text-white px-3 py-1 text-xs font-bold rounded">SALE</span>' : ''}
          ${product.newArrival ? '<span class="absolute top-3 left-3 bg-blue-600 text-white px-3 py-1 text-xs font-bold rounded">NEW</span>' : ''}
        </div>
        
        <div class="p-4">
          <p class="text-xs text-gray-400 uppercase tracking-wider">${product.category}</p>
          <h3 class="text-sm font-semibold text-white mt-2 line-clamp-2">${product.name}</h3>
          
          <div class="mt-3 flex items-baseline gap-2">
            <span class="text-lg font-bold text-yellow-500">${formatPrice(product.price)}</span>
            ${product.mrp ? `<span class="text-xs text-gray-400 line-through">${formatPrice(product.mrp)}</span>` : ''}
            ${discount > 0 ? `<span class="text-xs text-green-500">Save ${discount}%</span>` : ''}
          </div>
          
          ${product.mrp && product.mrp > product.price ? `<p class="text-xs text-green-500 font-semibold mt-1">Save ${formatPrice(product.mrp - product.price)}</p>` : ''}
          
          <div class="flex gap-1 mt-3 flex-wrap">
            ${product.sizes.slice(0, 4).map(size => `<span class="text-xs px-2 py-1 bg-gray-700 text-gray-300 rounded">${size}</span>`).join('')}
            ${product.sizes.length > 4 ? `<span class="text-xs px-2 py-1 bg-gray-700 text-gray-300 rounded">+${product.sizes.length - 4}</span>` : ''}
          </div>
          
          <p class="text-xs mt-3 ${inStock ? 'text-green-500' : 'text-red-500'} font-semibold">
            ${inStock ? '✓ In Stock' : '✗ Out of Stock'}
          </p>
          
          <button 
            class="w-full mt-4 bg-yellow-600 hover:bg-yellow-700 text-white text-sm font-semibold py-2 rounded transition order-btn"
            data-product-id="${product.id}"
            ${!inStock ? 'disabled' : ''}
          >
            ORDER NOW
          </button>
        </div>
      </div>
    `;
  }

  setupProductCardListeners() {
    document.querySelectorAll('.order-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const productId = btn.dataset.productId;
        const product = getProductById(productId);
        if (product) {
          window.location.href = `product.html?id=${productId}`;
        }
      });
    });
  }
}

// Initialize shop when DOM is ready
let shop;
document.addEventListener('DOMContentLoaded', () => {
  shop = new ShopManager();
});
