/**
 * Store Configuration
 * All important settings in one place for easy management
 */

const STORE_CONFIG = {
  // Store Information
  STORE_NAME: 'VINTAGE STYLE',
  STORE_WHATSAPP: '919876543210', // Change to your WhatsApp number (country code + number)
  STORE_PHONE: '+91-98765-43210',
  STORE_EMAIL: 'info@vintagestyle.local',
  
  // Location & Delivery
  STORE_LOCATION: 'Bangalore, India',
  STORE_SERVICE_AREA: 'Bangalore and surrounding areas',
  
  // Currency
  CURRENCY: '₹',
  CURRENCY_CODE: 'INR',
  
  // Delivery
  DELIVERY_CHARGES_RANGE: '₹49-99 depending on location',
  DELIVERY_TIME: '2-3 business days',
  SERVICE_AREAS: [
    'Indiranagar',
    'Koramangala',
    'Whitefield',
    'MG Road',
    'Jayanagar',
    'Marathahalli',
    'Bannerghatta Road',
  ],
  
  // Policies
  EXCHANGE_DAYS: 7,
  RETURN_DAYS: 14,
  
  // Business Hours
  BUSINESS_HOURS: '9 AM - 8 PM (Mon-Sat), Closed Sundays',
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = STORE_CONFIG;
}
